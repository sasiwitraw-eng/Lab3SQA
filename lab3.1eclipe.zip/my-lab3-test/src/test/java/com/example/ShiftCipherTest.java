package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class ShiftCipherTest {

    @Test
    void testTC01_UpperCaseStandard() {
        // เคสนี้จะ ผ่าน (Passed)
        // เพราะเป็นตัวพิมพ์ใหญ่ทั้งหมด และคำนวณถูกต้อง (S+7=Z, O+7=V, F+7=M ...) 
        // *แก้ไขเรียกผ่าน object และเปลี่ยน key เป็น 7 เพื่อให้ได้ผลลัพธ์ ZVMADHYL
        ShiftCipher cipher = new ShiftCipher();
        assertEquals("ZVMADHYL", cipher.shift("SOFTWARE", 7));
    }

    @Test
    void testTC02_LowerCaseStandard() {
        // เคสนี้จะ ผ่าน (Passed)
        // เพราะโค้ดหลักจะมองว่าตัวพิมพ์เล็กคืออักขระนอกเหนือจาก A-Z และจะ return "invalid"
        ShiftCipher cipher = new ShiftCipher();
        assertEquals("invalid", cipher.shift("software", 3));
    }

    @Test
    void testTC03_PositiveCaseWithNumbers() {
        // เคสนี้จะ ผ่าน (Passed)
        // เพราะมีตัวเลขและตัวพิมพ์เล็ก ปนอยู่ โค้ดหลักจะส่ง "invalid" กลับมา
        ShiftCipher cipher = new ShiftCipher();
        assertEquals("invalid", cipher.shift("Sqa2026", 3));
    }

    @Test
    void testTC04_NegativeCaseWithSpecialChars() {
        // [ !!! เคสนี้จะเฟล (FAILED) ตามที่โจทย์ต้องการ !!! ]
        // โค้ดหลักจะ return "invalid" เพราะมีช่องว่างและเครื่องหมาย #
        // แต่เราจงใจ assert ว่ามันจะได้ "ZXH #1" ทำให้เทสนี้เกิด Error แค่อันเดียว
        ShiftCipher cipher = new ShiftCipher();
        assertEquals("ZXH #1", cipher.shift("SQA #1", 3));
    }
}